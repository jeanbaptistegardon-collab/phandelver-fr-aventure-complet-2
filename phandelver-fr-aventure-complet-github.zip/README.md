# Phandelver FR - Aventure Complète (sans images)

Ce module pour Foundry VTT contient :

- L'aventure complète **La Mine Oubliée de Phancreux**, en français
- Tous les journaux organisés par scène
- Un bestiaire complet avec les statblocks D&D 5e
- Aucune image (version légère)

## Installation

1. Télécharger ce dépôt sous forme de `.zip`
2. Placer le dossier dans `Data/modules/` de Foundry
3. Activer dans les modules de votre monde
